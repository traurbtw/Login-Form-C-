﻿using System;
using System.Data;
using System.Windows.Forms;
using MySqlConnector;

namespace LoginForm
{
    public partial class Main : Form
    {
        // Строка подключения к базе данных (HOST, PORT, NAME, PASSWORD)
        private string connStr = "your database";

        public Main()
        {
            InitializeComponent();
        }

        private void UsernameTextBox_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void guna2PictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit(); // Закрытие приложения при нажатии на PictureBox
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            string username = UsernameTextBox.Text; 
            string password = PasswordTextBox.Text; 

            // Проверка на пустые поля
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Вы ничего не ввели");
                return;
            }

            // Подключение к базе данных и проверка логина и пароля
            using (MySqlConnection conn = new MySqlConnection(connStr))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT COUNT(*) FROM LoginForm WHERE Login = @username AND Password = @password";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@password", password);

                    int count = Convert.ToInt32(cmd.ExecuteScalar());

                    if (count > 0)
                    {
                        MessageBox.Show("Успешный вход!");
                        // Здесь можно открыть новую форму или выполнить другие действия после успешного входа
                    }
                    else
                    {
                        MessageBox.Show("Неверный логин или пароль.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка: " + ex.Message);
                    // Логирование всех ошибок
                }
            }
        }
    }
}