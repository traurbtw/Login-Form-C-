﻿namespace LoginForm
{
    partial class Main
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(this.components);
            this.ProductLabel = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.UsernameTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.PasswordTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.LoginButton = new Guna.UI2.WinForms.Guna2Button();
            this.ProductLogo = new Guna.UI2.WinForms.Guna2PictureBox();
            this.Exit = new Guna.UI2.WinForms.Guna2PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.ProductLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Exit)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2BorderlessForm1
            // 
            this.guna2BorderlessForm1.AnimateWindow = true;
            this.guna2BorderlessForm1.BorderRadius = 13;
            this.guna2BorderlessForm1.ContainerControl = this;
            this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 1D;
            this.guna2BorderlessForm1.DragStartTransparencyValue = 1D;
            this.guna2BorderlessForm1.ShadowColor = System.Drawing.Color.White;
            this.guna2BorderlessForm1.TransparentWhileDrag = true;
            // 
            // ProductLabel
            // 
            this.ProductLabel.BackColor = System.Drawing.Color.Transparent;
            this.ProductLabel.Font = new System.Drawing.Font("Kreadon Demi", 32F, System.Drawing.FontStyle.Bold);
            this.ProductLabel.IsSelectionEnabled = false;
            this.ProductLabel.Location = new System.Drawing.Point(131, 50);
            this.ProductLabel.Name = "ProductLabel";
            this.ProductLabel.Size = new System.Drawing.Size(212, 49);
            this.ProductLabel.TabIndex = 0;
            this.ProductLabel.Text = "Login Form";
            // 
            // UsernameTextBox
            // 
            this.UsernameTextBox.Animated = true;
            this.UsernameTextBox.BackColor = System.Drawing.Color.White;
            this.UsernameTextBox.BorderColor = System.Drawing.Color.Transparent;
            this.UsernameTextBox.BorderRadius = 1;
            this.UsernameTextBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.UsernameTextBox.CustomizableEdges.BottomLeft = false;
            this.UsernameTextBox.DefaultText = "";
            this.UsernameTextBox.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.UsernameTextBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.UsernameTextBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.UsernameTextBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.Black;
            this.UsernameTextBox.FocusedState.BorderColor = System.Drawing.Color.Black;
            this.UsernameTextBox.FocusedState.ForeColor = System.Drawing.Color.Black;
            this.UsernameTextBox.FocusedState.PlaceholderForeColor = System.Drawing.Color.Black;
            this.UsernameTextBox.Font = new System.Drawing.Font("Kreadon Demi", 15.75F, System.Drawing.FontStyle.Bold);
            this.UsernameTextBox.ForeColor = System.Drawing.Color.Black;
            this.UsernameTextBox.HoverState.BorderColor = System.Drawing.Color.Black;
            this.UsernameTextBox.HoverState.ForeColor = System.Drawing.Color.Black;
            this.UsernameTextBox.HoverState.PlaceholderForeColor = System.Drawing.Color.Black;
            this.UsernameTextBox.Location = new System.Drawing.Point(64, 125);
            this.UsernameTextBox.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.UsernameTextBox.Name = "UsernameTextBox";
            this.UsernameTextBox.PlaceholderForeColor = System.Drawing.SystemColors.MenuText;
            this.UsernameTextBox.PlaceholderText = "Username ";
            this.UsernameTextBox.SelectedText = "";
            this.UsernameTextBox.Size = new System.Drawing.Size(296, 33);
            this.UsernameTextBox.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.UsernameTextBox.TabIndex = 1;
            this.UsernameTextBox.TextChanged += new System.EventHandler(this.UsernameTextBox_TextChanged);
            // 
            // PasswordTextBox
            // 
            this.PasswordTextBox.Animated = true;
            this.PasswordTextBox.BackColor = System.Drawing.Color.White;
            this.PasswordTextBox.BorderColor = System.Drawing.Color.Transparent;
            this.PasswordTextBox.BorderRadius = 1;
            this.PasswordTextBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.PasswordTextBox.CustomizableEdges.BottomLeft = false;
            this.PasswordTextBox.DefaultText = "";
            this.PasswordTextBox.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.PasswordTextBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.PasswordTextBox.DisabledState.ForeColor = System.Drawing.Color.Black;
            this.PasswordTextBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.Black;
            this.PasswordTextBox.FocusedState.BorderColor = System.Drawing.Color.Black;
            this.PasswordTextBox.FocusedState.ForeColor = System.Drawing.Color.Black;
            this.PasswordTextBox.FocusedState.PlaceholderForeColor = System.Drawing.Color.Black;
            this.PasswordTextBox.Font = new System.Drawing.Font("Kreadon Demi", 15.75F, System.Drawing.FontStyle.Bold);
            this.PasswordTextBox.ForeColor = System.Drawing.Color.Black;
            this.PasswordTextBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.PasswordTextBox.Location = new System.Drawing.Point(64, 168);
            this.PasswordTextBox.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.PasswordTextBox.Name = "PasswordTextBox";
            this.PasswordTextBox.PlaceholderForeColor = System.Drawing.SystemColors.MenuText;
            this.PasswordTextBox.PlaceholderText = "Password";
            this.PasswordTextBox.SelectedText = "";
            this.PasswordTextBox.Size = new System.Drawing.Size(296, 33);
            this.PasswordTextBox.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.PasswordTextBox.TabIndex = 2;
        
            // 
            // LoginButton
            // 
            this.LoginButton.BorderRadius = 5;
            this.LoginButton.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.LoginButton.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.LoginButton.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.LoginButton.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.LoginButton.FillColor = System.Drawing.Color.Black;
            this.LoginButton.Font = new System.Drawing.Font("Kreadon Demi", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LoginButton.ForeColor = System.Drawing.Color.White;
            this.LoginButton.Location = new System.Drawing.Point(64, 238);
            this.LoginButton.Name = "LoginButton";
            this.LoginButton.Size = new System.Drawing.Size(296, 47);
            this.LoginButton.TabIndex = 3;
            this.LoginButton.Text = "Login";
            this.LoginButton.Click += new System.EventHandler(this.LoginButton_Click);
            // 
            // ProductLogo
            // 
            this.ProductLogo.Image = global::LoginForm.Properties.Resources.icons8_github_500;
            this.ProductLogo.ImageRotate = 0F;
            this.ProductLogo.Location = new System.Drawing.Point(71, 52);
            this.ProductLogo.Name = "ProductLogo";
            this.ProductLogo.Size = new System.Drawing.Size(53, 47);
            this.ProductLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ProductLogo.TabIndex = 5;
            this.ProductLogo.TabStop = false;
            // 
            // Exit
            // 
            this.Exit.Image = global::LoginForm.Properties.Resources.icons8_close_48__1_;
            this.Exit.ImageRotate = 0F;
            this.Exit.Location = new System.Drawing.Point(379, 12);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(22, 19);
            this.Exit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Exit.TabIndex = 4;
            this.Exit.TabStop = false;
            this.Exit.Click += new System.EventHandler(this.guna2PictureBox1_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(423, 346);
            this.Controls.Add(this.ProductLogo);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.LoginButton);
            this.Controls.Add(this.PasswordTextBox);
            this.Controls.Add(this.UsernameTextBox);
            this.Controls.Add(this.ProductLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form Login";
            ((System.ComponentModel.ISupportInitialize)(this.ProductLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Exit)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
        private Guna.UI2.WinForms.Guna2TextBox UsernameTextBox;
        private Guna.UI2.WinForms.Guna2HtmlLabel ProductLabel;
        private Guna.UI2.WinForms.Guna2TextBox PasswordTextBox;
        private Guna.UI2.WinForms.Guna2Button LoginButton;
        private Guna.UI2.WinForms.Guna2PictureBox Exit;
        private Guna.UI2.WinForms.Guna2PictureBox ProductLogo;
    }
}

